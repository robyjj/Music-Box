
var lyrics = [
{
  "id":"1"
   ,"song_name":"Turn It Up"
   ,"song_lyric":"You are here as we lift you up <br/> You are riding on our praise <br/> Be enthroned over everything <br/> You are seated in our praise <br/> This is prophetic, I can feel it in <br/> the air <br/>  <br/> We lift our praise and You change the atmosphere <br/> With hearts open now everybody singing out <br/>  <br/> Oh! <br/> Turn it up, this sound of praise <br/>  <br/> Make it louder than <br/> any other <br/>  <br/> Lift Him up and shout His name over all (yeah) <br/> As we praise, well I can feel the change <br/>  <br/> As your presence now invades <br/> Hear the sound of the broken chains <br/>  <br/> Prison doors are giving way <br/> This is prophetic, I can feel it in the air <br/>  <br/> We lift our praise and You change the atmosphere <br/> With hearts open now everybody <br/>  <br/> singing out <br/> I am free! <br/>  <br/> Turn it up, this sound of praise <br/> Make it louder than any other <br/>  <br/> Lift Him up and shout His name over all (yeah) <br/> Turn it up, this sound o <br/>  <br/>  praise <br/> Make it louder than any other <br/>  <br/> Lift Him up and shout His name over all (yeah) <br/> Our praise goes up <br/>  <br/> Your rain comes down <br/> Our praise goes up <br/>  <br/> Your rain comes down <br/> Our praise goes up <br/>  <br/> Your rain comes down <br/> Our praise goes up <br/>  <br/> Your rain comes down <br/> With shouts of praise we celebrate <br/>  <br/> King of glory <br/> enter in <br/>  <br/> You are riding on our praise <br/> Oh Lord <br/>  <br/> Turn it up, this sound of praise <br/> Make it louder than any other <br/>  <br/> Lift Him up and shout His name over all (yeah) <br/> Turn it up, this sound of praise <br/>  <br/> Make it louder than any other <br/> Lift Him up and shout His name over all (yeah)" 
   ,"starting" :"T"
},

{
  "id":"2"
   ,"song_name":"Beautiful One"
   ,"song_lyric":"Wonderful, so wonderful <br/> Is your unfailing love <br/> Your cross has spoken mercy over me <br/>  <br/> No eye has seen no ear has heard <br/> No heart could fully know <br/>  <br/> How <br/> glorious, how beautiful you are <br/>  <br/> Beautiful one I love you <br/> Beautiful one I adore <br/>  <br/> Beautiful one my soul must sing <br/> Powerful so powerful <br/>  <br/> Your glory fills the <br/> skies <br/>  <br/> Your mighty works displayed for all to see <br/> The beauty of your majesty <br/>  <br/> Awakes my heart to sing <br/> How marvellous how wonderful you are"
   ,"starting" :"B"
},
{
  "id":"3"
   ,"song_name":"Amazing Grace"
   ,"song_lyric":"Amazing Grace! <br/> How sweet the sound <br/> That saved a wretch like me <br/>  <br/> I once was lost but now am found <br/> Was blind but now I see <br/>  <br/> When we've been there ten <br/> thousand years <br/>  <br/> Bright shining as the sun <br/> We've no less days to sing God's praise <br/>  <br/> Than when we've first begun <br/> Through many dangers, toils and snares <br/>  <br/> I hav <br/>  already come <br/>  <br/> 'Tis Grace has brought me safe thus far <br/> And Grace will lead me home <br/>  <br/> Amazing Grace! <br/> How sweet the sound <br/>  <br/> That saved a wretch like me <br/> I onc <br/>  <br/>  was lost but now am found <br/> Was blind but now I see <br/>  <br/> Was blind but now I see" 
   ,"starting" :"A"
}, 
{
  "id":"4"
   ,"song_name":"Welcome Holy Spirit"
   ,"song_lyric":"Welcome Holy Spirit <br/> Be here with your presence <br/> Fill me with your power <br/>  <br/> Live inside of me <br/>  <br/>  <br/> You're the living water <br/> Never drying fountain <br/>  <br/> Comforter and counselor <br/> Take complete control" 
   ,"starting" :"W"
},
{
  "id":"5"
   ,"song_name":"King Of Majesty"
   ,"song_lyric":"You know that <br/> I love you <br/> You know that<br/>I want to know you so much more<br/>More than I have before<br/>These words are<br/>From my heart<br/>These words are<br/>Not made up<br/>I will live for you<br/>I am devoted to you<br/>King of Majesty<br/>I have one desire<br/>Just to be with you my Lord<br/>Just to be with you my Lord<br/>Jesus<br/>you are the Saviour of my soul<br/>And forever and ever I'll give my praises to you<br/>You know that<br/>I love you<br/>You know that<br/>I want to know you so much<br/>more<br/>More than I have before<br/>These words are<br/>From my heart<br/>These words are<br/>Not made up<br/>I will live for you<br/>I am devoted to you<br/>King of Majesty<br/>I have one desire<br/>Just to be with you my Lord<br/>Just to be with you my Lord<br/>Jesus you are the Saviour of my soul<br/>And forever and ever I'll give my praises to you<br/>Jesus you… " 
   ,"starting" :"K"
},
{
  "id":"6"
   ,"song_name":"Open the Eyes of my Heart"
   ,"song_lyric":"Open the eyes of my heart, Lord<br/>Open the eyes of my heart<br/>I want to see You<br/>I want to see You<br/>Open the eyes of my heart, Lord<br/>Open the eyes of my heart<br/>I want to see You<br/>I want to see You<br/>To see You high and lifted up<br/>Shinin' in the light of Your glory<br/>Pour out Your power and love<br/>As we sing holy, holy, holy<br/>Open the eyes of my heart, Lord<br/>Open the eyes of my heart<br/>I want to see You<br/>I want to see You<br/>Open the eyes of my heart, Lord<br/>Open the eyes of my heart<br/>I want to see You<br/>I want to see You<br/>To see You high and lifted up<br/>Shinin' in the light of Your glory<br/>Pour out Your power and love<br/>As we sing holy, holy, holy<br/>To see You high and lifted up<br/>Shinin' in the light of Your glory<br/>Pour out Your power and love<br/>As we sing holy, holy, holy<br/>To see You high and lifted up<br/>Shinin'…  " 
   ,"starting" :"O"
},
{
  "id":"7"
   ,"song_name":"My Redeemer Lives"
   ,"song_lyric":"I know he rescued my soul<br/>His blood has covered my sin<br/>I believe<br/>I believe<br/><br/>My shame He's taken away<br/>My pain is healed in his name<br/>I believe<br/>I believe<br/><br/>I'll raise a banner<br/>'Cause my Lord has conquered the grave<br/><br/>My Redeemer Lives<br/>My Redeemer Lives<br/>My Redeemer Lives<br/>My Redeemer Lives<br/><br/>I know He's rescued my soul<br/>His blood has covered my sin<br/>I believe<br/>I believe<br/><br/>My shame He's taken away<br/>My pain is healed in His Name<br/>I believe<br/>I believe<br/><br/>I'll raise a banner<br/>'Cause My Lord has conquered the grave<br/><br/>You Lift my burdens<br/>I'll rise with You<br/>I'm dancing on this mountain top to<br/>see your kingdom come<br/><br/>My Redeemer Lives<br/>My Redeemer Lives<br/>My Redeemer Lives<br/>My Redeemer Lives<br/>  " 
   ,"starting" :"M"
},
{
  "id":"8"
   ,"song_name":"Jesus Lover of my soul"
   ,"song_lyric":"Worship You My Lord<br/>Until the very end<br/>Worship you My Lord<br/>Until the very end<br/><br/>Jesus Lover of my soul<br/>Jesus i will never let you go<br/>youve<br/>taken me from the miry clay<br/>Set my feet upon a rock and now i know<br/><br/>I love you<br/>I need you<br/>Though my world may fall i'll never let you go<br/>My<br/>saviour, My closest friend.<br/>I will worship you<br/>Until the very end.  " 
   ,"starting" :"J"
},
{
  "id":"9"
   ,"song_name":"Holy, Holy, Holy"
   ,"song_lyric":"Holy, Holy, Holy Lord God Almighty<br/>Early in the morning, our song shall rise to Thee<br/>Holy, Holy, Holy merciful and mighty<br/>God in three persons blessed Trinity<br/><br/>Holy, Holy, Holy Lord God almighty<br/>All thy works shall praise Thy name in earth and sky and sea<br/>Holy, Holy, Holy merciful and mighty<br/>God in three persons<br/>blessed Trinity<br/><br/>Holy we cry holy [x4] " 
   ,"starting" :"H"
},
{
  "id":"10"
   ,"song_name":"Did You Feel The Mountains Tremble?"
   ,"song_lyric":"Did you feel the mountains tremble?<br/>Did you hear the oceans roar?<br/>When the people rose to sing of<br/>Jesus Christ the risen one<br/><br/>Did you feel the people tremble?<br/>Did you hear the singers roar?<br/>When the lost began to sing of<br/>Jesus Christ the saving one<br/><br/>And we can see that God you're moving<br/>A mighty river through the nations<br/>When young and old return to Jesus<br/>Fling wide your heavenly gates<br/>Prepare the way<br/>of the risen Lord<br/><br/>Open up the doors and let the music play<br/>Let the streets resound with singing<br/>Songs that bring your hope<br/>Songs that bring your joy<br/>Dancers who dance upon injustice<br/><br/>Did you feel the darkness tremble<br/>When all the saints join in one song<br/>And all the streams flow as one river<br/>To wash away<br/>our brokeness<br/><br/>And we can see that God you're moving<br/>A time of Jubilee is coming<br/>When young and old will turn to Jesus<br/>Fling wide your heavenly gates<br/>Prepare the way of the risen Lord<br/><br/>[chorus]" 
   ,"starting" :"D"
},
{
  "id":"11"
   ,"song_name":"One Way"
   ,"song_lyric":"I lay my life down at Your feet<br/>Cause You're the only one I need<br/>I turn to You and You are always there<br/><br/>In troubled times it's You I seek<br/>I put You<br/>first that's all I need<br/>I humble all I am all to You<br/><br/>One way<br/>Jesus<br/>You're the only one that I could live for<br/>One Way<br/>Jesus<br/>You're the only one<br/>that I could live for<br/><br/>You are always, always there<br/>Every how and everywhere<br/>Your grace abounds so deeply within me<br/><br/>You will never ever change<br/>Yesterday today the same<br/>Forever till forever meets no end<br/><br/>You are the Way the Truth and the Life<br/>We live by faith and not by sight for You<br/>We're living<br/>all for You " 
   ,"starting" :"O"
},
{
  "id":"12"
   ,"song_name":"Majesty"
   ,"song_lyric":"Majesty<br/>Majesty<br/>your grace has found me just as I am<br/>Empty handed but alive in Your hands<br/><br/>Singing Majesty<br/>Majesty<br/>Forever I am changed by<br/>Your love<br/>In the beauty of Your Majesty<br/>Majesty" 
   ,"starting" :"M"
},
{
  "id":"13"
   ,"song_name":"Mighty To Save"
   ,"song_lyric":"Everyone needs compassion<br/>A love that's never failing<br/>Let mercy fall on me<br/><br/>Everyone needs forgiveness<br/>The kindness of a Saviour<br/>The hope of nations<br/><br/>[Chorus:]<br/>Saviour, he can move the mountains<br/>My God is mighty to save<br/>He is mighty to save<br/>Forever Author of Salvation<br/>He rose and conquered the grave<br/>Jesus conquered the grave<br/><br/>So take me as you find me<br/>All my fears and failures<br/>Fill my life again<br/><br/>I give my life to follow<br/>Everything that I<br/>believe in<br/>Now I surrender<br/><br/>[Chorus]<br/><br/>Shine your light and let the whole world see<br/>We're singing for the glory of the risen king Jesus [2x]<br/><br/>[Chorus x2]<br/><br/>Shine your light and let the whole world see<br/>We're singing for the glory of the risen king Jesus [6x] " 
   ,"starting" :"M"
},
{
  "id":"14"
   ,"song_name":"Our God is an awesome God"
   ,"song_lyric":"When He rolls up His sleeves<br/>He ain't just putting on the ritz<br/>(Our God is an awesome God)<br/>There's thunder in His footsteps<br/>And lightning in His fists<br/>(Our God is an awesome God)<br/>And the Lord wasn't joking<br/>When He kicked 'em out of Eden<br/>It wasn't for no reason<br/>That He shed His blood<br/>His return is very close<br/>And so you better be believing that<br/>Our God is an awesome God<br/>Our God is an awesome God<br/>He reigns from heaven above<br/>With wisdom, power, and love<br/>Our God is<br/>an awesome God<br/>Our God is an awesome God<br/>He reigns from heaven above<br/>With wisdom, power, and love<br/>Our God is an awesome God<br/>And when the sky was starless<br/>In the void of the night<br/>(Our God is an awesome God)<br/>He spoke into the darkness<br/>And created the light<br/>(Our God is an awesome God)  " 
   ,"starting" :"O"
},
{
  "id":"15"
   ,"song_name":"Jehovah-Jireh"
   ,"song_lyric":"Jehovah Jireh<br/>My provider<br/>His grace is sufficient<br/>For me, for me, for me<br/><br/>Jehovah Jireh<br/>My provider<br/>His grace is sufficient<br/>For me<br/><br/>My God shall supply all my needs<br/>According to His riches in glory<br/>He will give His angels<br/>Charge over me<br/><br/>Jehovah Jireh cares for me, for me, for me<br/>Jehovah Jireh cares for me<br/><br/>Jehovah Jireh<br/>My provider<br/>His grace is sufficient<br/>For me, for me, for me<br/><br/>Jehovah Jireh<br/>My provider<br/>His grace is<br/>sufficient<br/>For me<br/><br/>My God shall supply all my needs<br/>According to His riches in glory<br/>He will give His angels<br/>Charge over me<br/><br/>Jehovah Jireh cares<br/>for me, for me, for me<br/>Jehovah Jireh cares for me<br/><br/>My God shall supply all my needs<br/>According to His riches in glory<br/>He will give His angels<br/>Charge<br/>over me<br/><br/>Jehovah Jireh cares for me, for me, for me<br/>Jehovah Jireh cares for me, for me, for me<br/>Jehovah Jireh cares for me<br/><br/>My God shall<br/>supply all my needs<br/>According to His riches in glory<br/>He will give His angels<br/>Charge over me<br/><br/>Jehovah Jireh cares for me, for me, for me<br/>Jehovah Jireh<br/>cares for me, for me, for me<br/>Jehovah Jireh cares for me<br/> " 
   ,"starting" :"J"
},
{
  "id":"17"
   ,"song_name":"All To Jesus"
   ,"starting" :"A"
   ,"song_lyric":"All to Jesus, I surrender<br/>All to Him I freely give<br/>I will ever love and trust Him,<br/>In His presence daily live.<br/><br/>I surrender all, I surrender all,<br/>All to Thee, my blessèd Savior,<br/>I surrender all.<br/><br/>All to Jesus I surrender;<br/>Humbly at His feet I bow,<br/>Worldly pleasures all forsaken;<br/>Take me, Jesus, take me now    || I surrender all ||<br/><br/>All to Jesus, I surrender<br/>Make me, Savior, wholly Thine<br/>Let me feel the Holy Spirit,<br/>Truly know that Thou art mine.     || I surrender all ||<br/><br/>All to Jesus, I surrender;<br/>Lord, I give myself to Thee;<br/>Fill me with Thy love and power;<br/>Let Thy blessing fall on me.     || I surrender all ||"

},
{
  "id":"18"
   ,"song_name":"As the deer panteth"
   ,"starting" :"A"
   ,"song_lyric":"As the deer panteth for the water<br/>So my soul longeth after thee<br/>You alone are my heart’s desire<br/>And I long to worship thee<br/><br/>You alone are my strength,<br/>my shield<br/>To you alone may my spirit yield<br/>You alone are my heart’s desire<br/>And I long to worship thee<br/><br/>You’re my friend and you are my brother<br/>Even<br/>though you are a king<br/>I love you more than any other<br/>So much more than anything<br/><br/>You alone are my strength, my shield<br/>To you alone may my spirit<br/>yield<br/>You alone are my heart’s desire<br/>And I long to worship thee<br/><br/>I love you more than gold or silver,<br/>only you can satisfy.<br/>You alone are the real<br/>joy giver<br/>and the apple of my eye.<br/><br/>You alone are my strength, my shield<br/>To you alone may my spirit yield<br/>You alone are my heart’s desire<br/>And I long to worship you "
},
{
  "id":"19"
   ,"song_name":"Bind Us Together"
   ,"starting" :"B"
   ,"song_lyric":"Bind us together, Lord<br/>Bind us together<br/>With cords that cannot be broken<br/>Bind us together, Lord<br/>Bind us together<br/>Bind us together in Love<br/><br/>There is only one God,<br/>There is only one King<br/>There is only one Body,<br/>That is why we sing.        <br/><br/><b> (Bind us..)</b><br/><br/>Fit for the glory of God,<br/>Purchased by His precious Son<br/>Born with the right to be free<br/>For Jesus the victory has won.         <br/><br/><b> (Bind us..)</b><br/><br/>We are the family of God<br/>We are the promise divine<br/>We are God’s chosen desire<br/>We are the glorious new wine.      <br/><br/><b> (Bind us..)</b><br/>"
},
{
  "id":"20"
   ,"song_name":"Blessed Assurance"
   ,"starting" :"B"
   ,"song_lyric":"Blessed assurance, Jesus is mine!<br/>Oh, what a foretaste of glory divine!<br/>Heir of salvation, purchase of God,<br/>Born of His Spirit, washed in His blood.<br/><br/>This is my story, this is my song,<br/>Praising my Savior all the day long;<br/>This is my story, this is my song,<br/>Praising my Savior all the day long.<br/><br/>Perfect submission, perfect delight,<br/>Visions of rapture now burst on my sight;<br/>Angels descending bring from above,<br/>Echoes of mercy, whispers of love.        <br/><br/><b>(This is my story..)</b><br/><br/>Perfect submission, all is at rest,<br/>I in my Savior am happy and blest;<br/>Watching and waiting, looking above,<br/>Filled with His goodness lost in His love.      <br/><br/><b>(This is my story..)</b><br/>"

},
{
  "id":"21"
   ,"song_name":"When upon life's billows"
   ,"starting": "W"
   ,"song_lyric":"When upon life’s billows you are tempest tossed,<br/>When you are discouraged, thinking all is lost,<br/>Count your many blessings, name them one by one,<br/>And it will surprise you what the Lord hath done.<br/><br/>Count your blessings, name them one by one,<br/>Count your blessings, see what God hath done!<br/>Count your blessings, name them one by one,<br/>And it will surprise you what the Lord hath done.<br/><br/>Are you ever burdened with a load of care?<br/>Does the cross seem heavy you are called to bear?<br/>Count your many blessings, every doubt will fly,<br/>And you will keep singing as the days go by. <br/><br/><b>(Count your blessings..)</b><br/><br/>When you look at others with their lands and gold,<br/>Think that Christ has promised you His wealth untold;<br/>Count your many blessings. Wealth can never buy<br/>Your reward in heaven, nor your home on high. <br/><br/><b>(Count your blessings..)</b><br/><br/>So, amid the conflict whether great or small,<br/>Do not be disheartened, God is over all;<br/>Count your many blessings, angels will attend,<br/>Help and comfort give you to your journey’s end. <br/><br/><b>(Count your blessings..)</b><br/>"
}
];
var startingLettersUnique =[];

function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function redirectToSong(songId)
{
   window.location = './html/song.html?songId='+songId;
  
}

function populateSong()
{
  var id = getParameterByName('songId');

  var songDetails = $.grep(lyrics, function(e){ return e.id == id; });

   $("#songLyric").html(songDetails[0].song_lyric);
   $("#songTitle").html(songDetails[0].song_name)
}


//Sorting the song list
function predicateBy(prop){

   return function(a,b){
      if( a[prop] > b[prop]){
          return 1;
      }else if( a[prop] < b[prop] ){
          return -1;
      }
      return 0;
   }
}

$(document).ready(function(){

var startingLetters =[];
var div_song_list_start="<ul id=\"ulSongList\"data-role=\"listview\" data-filter=\"true\" data-filter-placeholder=\"Search Songs...\" data-inset=\"true\">";
var div_song_list_end =" </ul>"
var list="";

lyrics.sort(predicateBy("song_name"));
$(lyrics).each(function( index ,data) {
  index = index +1;
  console.log( index + ": " + $( this ).text() + data.song_name );
  $("#ulSongList").append("<li onClick=\"redirectToSong("+data.id+")\">"+data.song_name+"</li>");
  startingLetters.push(data.starting);
  startingLettersUnique = startingLetters.filter(function(elem, index, self) {
     return index == self.indexOf(elem);
});
 startingLettersUnique=startingLettersUnique.sort();
 // list =list + "<li onClick=\"redirectToSong("data.id")\">"+data.song_name"</li>";
  
});
 $("#ulSongList").append("</ul>");


 $(startingLettersUnique).each(function(index,data)
{
   $('#select_letter').append('<option value=' + data +'> ' + data + '</option>');
});
//poplateSongNameByStartingLetter('A');


$("#select_letter").change(function(e){
 var letter =$(this).val();
 $('#select_song').empty();
 poplateSongNameByStartingLetter(letter);

 //The below code removes the existing selection and repopulates correct selection
 $('span.select_song').text($("#select_song option:first").text())

});

$("#select_song").change(function(e){
 var songID =$(this).val();
 redirectToSong(songID);

});


function poplateSongNameByStartingLetter(letter)
{
  //get songs based on starting letter
 var songsFilteredByLetter = $.grep(lyrics, function(e)
  { return e.starting == letter; 
  });
  //destroySelectSong();
  // $('#select_song').html('');
  // $('.select_song').empty();
   $("#ulSongList").empty();
 $(songsFilteredByLetter).each(function(index,data)
 {

  $("#ulSongList").append("<li class=\"ui-li-static ui-body-inherit\" onClick=\"redirectToSong("+data.id+")\">"+data.song_name+"</li>");
  //$('#select_song').append('<option value=' + data.id +' onclick=redirectToSong('+data.id+')> ' + data.song_name + '</option>');
  $('#select_song').append('<option value=' + data.id +'> ' + data.song_name + '</option>');
 }); 
$("#ulSongList").append("</ul>");
 //$("#select_song").val($("#select_song option:first").val());

}
//var songList = div_song_list_start + list+div_song_list_end;
  $( ".opensearch" ).on( 'click', tapHandler );
    
  function tapHandler( event ) {
    $('.search_field').slideToggle();
    setTimeout(function(){
     $('#search').focus().tap();
    },0);
  }



// var div_song_list_start="<div class=\"row\"> <div class=\"col s6 m2 \"> <div class=\"card-panel\" onClick=\"redirectToSong(replaceId)\"> <span class=\"black-text\">";
// var div_song_list_end =" </span>        </div>      </div>    </div> "
// $(lyrics).each(function( index ,data) {
//  index = index +1;
//   console.log( index + ": " + $( this ).text() + data.song_name );
//   var songList = div_song_list_start + data.song_name+div_song_list_end;
//   songList = songList.replace("replaceId",data.id);
//   $("#divSongList").append(songList);
// });



});